# Highlight Reader 发布安装包说明

本文说明如何生成可安装的 Android 安装包。

## 产物类型

- Debug APK：用于测试安装，不适合公开发布。
- Release APK：可直接发给用户安装。
- Release AAB：用于 Google Play 等应用商店上传。

## 推荐方案：GitHub Actions 云端打包

当前项目已包含 `.github/workflows/android-release.yml`，上传到 GitHub 后可以在云端生成安装包。

如果你使用本次生成的凭据包，可以直接打开 `private_release_credentials/github-secrets.txt`，把其中 4 行分别填到 GitHub Secrets。请不要把 `private_release_credentials.zip`、`.jks` 或 Secrets 内容上传到公开仓库。

项目也提供了推送脚本：

```bash
bash scripts/push_to_github.sh https://github.com/你的用户名/你的仓库.git
```

推送完成后，再到 GitHub 页面配置 Secrets 并运行工作流。

### 准备签名证书

在有 JDK 的电脑上执行：

```bash
keytool -genkeypair \
  -v \
  -keystore highlight-reader-release.jks \
  -alias highlight-reader \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

请妥善保存：

- `highlight-reader-release.jks`
- keystore 密码
- key alias
- key 密码

签名证书丢失后，已发布应用将无法用同一身份升级。

### 转成 Base64

macOS / Linux：

```bash
base64 -w 0 highlight-reader-release.jks > keystore.base64
```

如果你的系统不支持 `-w 0`：

```bash
base64 highlight-reader-release.jks | tr -d '\n' > keystore.base64
```

Windows PowerShell：

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("highlight-reader-release.jks")) > keystore.base64
```

### 配置 GitHub Secrets

进入 GitHub 仓库：

`Settings` → `Secrets and variables` → `Actions` → `New repository secret`

添加以下 4 个 Secret：

```text
ANDROID_KEYSTORE_BASE64
ANDROID_KEYSTORE_PASSWORD
ANDROID_KEY_ALIAS
ANDROID_KEY_PASSWORD
```

其中：

- `ANDROID_KEYSTORE_BASE64`：填写 `keystore.base64` 文件内容。
- `ANDROID_KEYSTORE_PASSWORD`：填写 keystore 密码。
- `ANDROID_KEY_ALIAS`：默认示例为 `highlight-reader`。
- `ANDROID_KEY_PASSWORD`：填写 key 密码。

### 触发云端打包

进入 GitHub 仓库：

`Actions` → `Android Release Build` → `Run workflow`

完成后在 Workflow 页面底部下载 Artifacts：

- `highlight-reader-debug-apk`
- `highlight-reader-release-apk`
- `highlight-reader-release-aab`

Release APK 文件路径通常为：

```text
app/build/outputs/apk/release/HighlightReader-1.0.0-release.apk
```

Release AAB 文件路径通常为：

```text
app/build/outputs/bundle/release/app-release.aab
```

## 本地打包

如果你的电脑安装了 Android Studio，可以直接打开项目并同步 Gradle。

### 配置本地签名

复制模板：

```bash
cp release/keystore.properties.example release/keystore.properties
```

把 `highlight-reader-release.jks` 放到 `release/` 目录，并编辑：

```properties
storeFile=release/highlight-reader-release.jks
storePassword=你的_keystore_密码
keyAlias=highlight-reader
keyPassword=你的_key_密码
```

### 构建安装包

如果你安装了 Gradle：

```bash
gradle :app:assembleRelease
```

如果你只想测试：

```bash
gradle :app:assembleDebug
```

## 修改版本号

编辑 `app/build.gradle.kts`：

```kotlin
versionCode = 1
versionName = "1.0.0"
```

每次正式发布新版本时：

- `versionCode` 必须递增。
- `versionName` 可以按产品版本填写，例如 `1.0.1`、`1.1.0`。

## 修改应用包名

当前包名为：

```text
com.highlight.reader
```

如果要正式发布到应用商店，建议改成你自己的唯一包名，例如：

```text
com.yourcompany.reader
```

修改位置：

```kotlin
applicationId = "com.highlight.reader"
namespace = "com.example.highlightreader"
```

`applicationId` 是用户设备和应用商店识别应用的身份，发布后不要随意更改。

## 安装 Release APK

把 Release APK 发到安卓手机后，允许“安装未知来源应用”，点击 APK 即可安装。

如果安装失败，常见原因是：

- 手机已有同包名但签名不同的旧版本，需要先卸载旧版本。
- Android 系统版本低于 `minSdk = 26`。
- APK 下载过程损坏，重新下载即可。
