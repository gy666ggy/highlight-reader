#!/usr/bin/env bash
set -euo pipefail

SECRETS_FILE="private_release_credentials/github-secrets.txt"

if [ ! -f "$SECRETS_FILE" ]; then
  echo "未找到 $SECRETS_FILE"
  echo "请确认已经生成发布签名凭据。"
  exit 1
fi

echo "请在 GitHub 仓库中配置以下 Secrets："
echo "Settings → Secrets and variables → Actions → New repository secret"
echo
cat "$SECRETS_FILE"
echo
echo "注意：不要把这些内容提交到公开仓库。"
