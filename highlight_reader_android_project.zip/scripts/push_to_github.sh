#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "用法：bash scripts/push_to_github.sh <你的 GitHub 仓库地址>"
  echo "示例：bash scripts/push_to_github.sh git@github.com:yourname/highlight-reader.git"
  echo "示例：bash scripts/push_to_github.sh https://github.com/yourname/highlight-reader.git"
  exit 1
fi

REPO_URL="$1"

if [ ! -d ".git" ]; then
  git init
fi

git branch -M main
git add .
git reset -- private_release_credentials private_release_credentials.zip 2>/dev/null || true

if ! git diff --cached --quiet; then
  git -c user.name="Highlight Reader Builder" \
      -c user.email="builder@example.com" \
      commit -m "Release-ready Android reader app"
fi

if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$REPO_URL"
else
  git remote add origin "$REPO_URL"
fi

git push -u origin main

echo "已推送到 GitHub。"
echo "下一步：进入 GitHub 仓库 Settings → Secrets and variables → Actions，填入 private_release_credentials/github-secrets.txt 中的 4 个 Secrets。"
echo "然后进入 Actions → Android Release Build → Run workflow。"
