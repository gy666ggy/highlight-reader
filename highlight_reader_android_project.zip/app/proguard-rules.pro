# Highlight Reader 发布版混淆规则

# Compose、AndroidX 和 Kotlin 的基础规则通常由依赖自带 consumer rules 提供。
# 当前项目未使用反射型序列化框架，保留规则保持轻量。

-keep class com.example.highlightreader.MainActivity { *; }
-keep class com.example.highlightreader.model.** { *; }
-dontwarn org.json.**
