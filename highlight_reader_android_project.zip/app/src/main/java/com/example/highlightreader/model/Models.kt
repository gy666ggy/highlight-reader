package com.example.highlightreader.model

import androidx.compose.ui.graphics.Color

data class Book(
    val id: String,
    val title: String,
    val content: String,
    val lastOffset: Int = 0,
)

data class Chapter(
    val index: Int,
    val title: String,
    val start: Int,
    val end: Int,
) {
    val length: Int get() = (end - start).coerceAtLeast(0)
}

data class Bookmark(
    val id: String,
    val bookId: String,
    val chapterIndex: Int,
    val offset: Int,
    val title: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
)

data class HighlightRule(
    val id: String,
    val name: String,
    val pattern: String,
    val color: Int,
    val regex: Boolean = false,
    val caseSensitive: Boolean = false,
    val enabled: Boolean = true,
    val priority: Int = 0,
)

data class ReaderSettings(
    val fontSize: Float = 20f,
    val lineHeight: Float = 1.65f,
    val theme: ReaderTheme = ReaderTheme.Sepia,
    val pageChars: Int = 3600,
    val paragraphIndent: Boolean = true,
)

data class SourceRule(
    val id: String,
    val name: String,
    val baseUrl: String,
    val searchUrl: String,
    val bookNameSelector: String,
    val chapterListSelector: String,
    val contentSelector: String,
    val enabled: Boolean = false,
)

enum class Screen {
    Shelf,
    Reader,
    Rules,
    Sources,
}

enum class ReaderTheme(val label: String, val background: Color, val text: Color) {
    Sepia("护眼", Color(0xFFFFF8EF), Color(0xFF2A2118)),
    Light("明亮", Color(0xFFFFFFFF), Color(0xFF111827)),
    Dark("夜间", Color(0xFF111827), Color(0xFFE5E7EB)),
}
