package com.example.highlightreader.ui.sources

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.highlightreader.domain.SourceRuleEngine
import com.example.highlightreader.domain.SourceSearchRequest
import com.example.highlightreader.model.SourceRule
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SourceRulesScreen(
    sources: List<SourceRule>,
    onBack: () -> Unit,
    onSourcesChange: (List<SourceRule>) -> Unit,
) {
    var editing by remember { mutableStateOf<SourceRule?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("书源规则") },
                navigationIcon = { TextButton(onClick = onBack) { Text("返回") } },
                actions = {
                    TextButton(onClick = {
                        editing = null
                        showEditor = true
                    }) { Text("新增") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFFFF8EF)),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFFFF8EF))
                .padding(padding)
                .padding(18.dp),
        ) {
            Text("当前为书源规则骨架：定义搜索 URL 与 CSS 选择器，供后续接入网络抓取、净化、换源与缓存。", color = Color(0xFF6B5E54))
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(sources, key = { it.id }) { source ->
                    SourceCard(
                        source = source,
                        onToggle = {
                            onSourcesChange(sources.map { if (it.id == source.id) it.copy(enabled = !it.enabled) else it })
                        },
                        onEdit = {
                            editing = source
                            showEditor = true
                        },
                        onDelete = {
                            onSourcesChange(sources.filterNot { it.id == source.id })
                        },
                    )
                }
            }
        }
    }

    if (showEditor) {
        SourceEditorDialog(
            source = editing,
            onDismiss = { showEditor = false },
            onSave = { saved ->
                onSourcesChange(
                    if (editing == null) listOf(saved) + sources else sources.map { if (it.id == saved.id) saved else it },
                )
                showEditor = false
            },
        )
    }
}

@Composable
private fun SourceCard(source: SourceRule, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val errors = SourceRuleEngine.validate(source)
    val plan = SourceRuleEngine.buildSearchPlan(source, SourceSearchRequest("示例"))
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(source.name, fontWeight = FontWeight.Bold)
                    Text(source.baseUrl, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color(0xFF6B7280))
                }
                Checkbox(checked = source.enabled, onCheckedChange = { onToggle() })
            }
            Text("搜索示例：${plan.searchUrl}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color(0xFF6B7280))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(if (source.enabled) "已启用" else "未启用") })
                AssistChip(onClick = {}, label = { Text(if (errors.isEmpty()) "校验通过" else "${errors.size} 个问题") })
            }
            if (errors.isNotEmpty()) {
                Text(errors.joinToString("；"), color = Color(0xFFB45309))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onEdit) { Text("编辑") }
                OutlinedButton(onClick = onDelete) { Text("删除") }
            }
        }
    }
}

@Composable
private fun SourceEditorDialog(source: SourceRule?, onDismiss: () -> Unit, onSave: (SourceRule) -> Unit) {
    var name by remember(source) { mutableStateOf(source?.name ?: "") }
    var baseUrl by remember(source) { mutableStateOf(source?.baseUrl ?: "") }
    var searchUrl by remember(source) { mutableStateOf(source?.searchUrl ?: "/search?q={keyword}&page={page}") }
    var bookNameSelector by remember(source) { mutableStateOf(source?.bookNameSelector ?: ".book-title") }
    var chapterListSelector by remember(source) { mutableStateOf(source?.chapterListSelector ?: ".chapter-list a") }
    var contentSelector by remember(source) { mutableStateOf(source?.contentSelector ?: ".chapter-content") }
    var enabled by remember(source) { mutableStateOf(source?.enabled ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (source == null) "新增书源规则" else "编辑书源规则") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("名称") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = searchUrl, onValueChange = { searchUrl = it }, label = { Text("搜索 URL，含 {keyword}") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = bookNameSelector, onValueChange = { bookNameSelector = it }, label = { Text("书名选择器") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = chapterListSelector, onValueChange = { chapterListSelector = it }, label = { Text("目录选择器") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = contentSelector, onValueChange = { contentSelector = it }, label = { Text("正文选择器") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = enabled, onCheckedChange = { enabled = it })
                    Text("启用规则")
                }
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank() && baseUrl.isNotBlank(),
                onClick = {
                    onSave(
                        SourceRule(
                            id = source?.id ?: UUID.randomUUID().toString(),
                            name = name,
                            baseUrl = baseUrl,
                            searchUrl = searchUrl,
                            bookNameSelector = bookNameSelector,
                            chapterListSelector = chapterListSelector,
                            contentSelector = contentSelector,
                            enabled = enabled,
                        ),
                    )
                },
            ) { Text("保存") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}
