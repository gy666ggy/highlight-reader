package com.example.highlightreader.ui.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.highlightreader.domain.ChapterParser
import com.example.highlightreader.domain.HighlightEngine
import com.example.highlightreader.model.Book
import com.example.highlightreader.model.Bookmark
import com.example.highlightreader.model.Chapter
import com.example.highlightreader.model.HighlightRule
import com.example.highlightreader.model.ReaderSettings
import com.example.highlightreader.model.ReaderTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    book: Book?,
    rules: List<HighlightRule>,
    settings: ReaderSettings,
    bookmarks: List<Bookmark>,
    onBack: () -> Unit,
    onRules: () -> Unit,
    onSettingsChange: (ReaderSettings) -> Unit,
    onBookmarksChange: (List<Bookmark>) -> Unit,
    onProgressChange: (Book, Int) -> Unit,
) {
    if (book == null) {
        EmptyReader(onBack)
        return
    }

    val chapters = remember(book.id, book.content) { ChapterParser.parse(book.content) }
    var offset by remember(book.id) { mutableIntStateOf(book.lastOffset.coerceIn(0, max(0, book.content.length - 1))) }
    var search by remember { mutableStateOf("") }
    var showToc by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showBookmarkEditor by remember { mutableStateOf(false) }

    val content = book.content
    val start = offset.coerceIn(0, max(0, content.length - 1))
    val end = min(content.length, start + settings.pageChars)
    val visibleText = content.substring(start, end)
    val progress = if (content.isBlank()) 0f else start.toFloat() / content.length.toFloat()
    val currentChapter = ChapterParser.findChapter(chapters, start)
    val theme = settings.theme
    val displayedText = if (settings.paragraphIndent) visibleText.indentParagraphs() else visibleText

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(book.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { TextButton(onClick = onBack) { Text("书架") } },
                actions = {
                    TextButton(onClick = { showToc = true }) { Text("目录") }
                    TextButton(onClick = { showBookmarks = true }) { Text("笔记") }
                    TextButton(onClick = onRules) { Text("规则") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = theme.background),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(theme.background)
                .padding(padding)
                .padding(horizontal = 18.dp),
        ) {
            Spacer(Modifier.height(8.dp))
            Text(currentChapter.title, color = theme.text.copy(alpha = 0.72f), fontSize = 13.sp, maxLines = 1)
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("搜索当前页") },
            )
            Spacer(Modifier.height(8.dp))

            SelectionContainer(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = HighlightEngine.render(displayedText, rules, search),
                    color = theme.text,
                    fontSize = settings.fontSize.sp,
                    lineHeight = (settings.fontSize * settings.lineHeight).sp,
                    fontFamily = FontFamily.Serif,
                    modifier = Modifier.padding(vertical = 12.dp),
                )
            }

            Text(
                "进度 ${(progress * 100).toInt()}% · ${start + 1}-$end · ${currentChapter.title}",
                color = theme.text.copy(alpha = 0.68f),
                fontSize = 12.sp,
            )
            Slider(
                value = progress,
                onValueChange = { value ->
                    val newOffset = (value * content.length).toInt().coerceIn(0, max(0, content.length - 1))
                    offset = newOffset
                    onProgressChange(book, newOffset)
                },
            )
            ReaderControlBar(
                settings = settings,
                onSettingsChange = onSettingsChange,
                onPrevious = {
                    val newOffset = max(0, start - settings.pageChars)
                    offset = newOffset
                    onProgressChange(book, newOffset)
                },
                onNext = {
                    val newOffset = min(max(0, content.length - 1), end)
                    offset = newOffset
                    onProgressChange(book, newOffset)
                },
                onAddBookmark = { showBookmarkEditor = true },
                onSettings = { showSettings = true },
            )
            Spacer(Modifier.height(10.dp))
        }
    }

    if (showToc) {
        ChapterDialog(
            chapters = chapters,
            current = currentChapter,
            onDismiss = { showToc = false },
            onJump = {
                offset = it.start
                onProgressChange(book, it.start)
                showToc = false
            },
        )
    }

    if (showBookmarks) {
        BookmarkDialog(
            bookmarks = bookmarks.sortedByDescending { it.createdAt },
            onDismiss = { showBookmarks = false },
            onJump = {
                offset = it.offset
                onProgressChange(book, it.offset)
                showBookmarks = false
            },
            onDelete = { target ->
                onBookmarksChange(bookmarks.filterNot { it.id == target.id })
            },
        )
    }

    if (showBookmarkEditor) {
        BookmarkEditorDialog(
            chapter = currentChapter,
            onDismiss = { showBookmarkEditor = false },
            onSave = { note ->
                onBookmarksChange(
                    bookmarks + Bookmark(
                        id = UUID.randomUUID().toString(),
                        bookId = book.id,
                        chapterIndex = currentChapter.index,
                        offset = start,
                        title = currentChapter.title,
                        note = note,
                    ),
                )
                showBookmarkEditor = false
            },
        )
    }

    if (showSettings) {
        ReaderSettingsDialog(
            settings = settings,
            onDismiss = { showSettings = false },
            onSettingsChange = onSettingsChange,
        )
    }
}

@Composable
private fun ReaderControlBar(
    settings: ReaderSettings,
    onSettingsChange: (ReaderSettings) -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onAddBookmark: () -> Unit,
    onSettings: () -> Unit,
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onPrevious) { Text("上一页") }
            Button(onClick = onNext) { Text("下一页") }
            OutlinedButton(onClick = onAddBookmark) { Text("加书签") }
            OutlinedButton(onClick = onSettings) { Text("设置") }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("字号", fontWeight = FontWeight.SemiBold)
            OutlinedButton(onClick = { onSettingsChange(settings.copy(fontSize = max(14f, settings.fontSize - 1))) }) { Text("-") }
            Text("${settings.fontSize.toInt()}sp")
            OutlinedButton(onClick = { onSettingsChange(settings.copy(fontSize = min(32f, settings.fontSize + 1))) }) { Text("+") }
        }
    }
}

@Composable
private fun ChapterDialog(chapters: List<Chapter>, current: Chapter, onDismiss: () -> Unit, onJump: (Chapter) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("目录（${chapters.size} 章）") },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(chapters, key = { it.index }) { chapter ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onJump(chapter) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            chapter.title,
                            modifier = Modifier.weight(1f),
                            fontWeight = if (chapter.index == current.index) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text("${chapter.length} 字", fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("关闭") } },
    )
}

@Composable
private fun BookmarkDialog(
    bookmarks: List<Bookmark>,
    onDismiss: () -> Unit,
    onJump: (Bookmark) -> Unit,
    onDelete: (Bookmark) -> Unit,
) {
    val formatter = remember { SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("书签笔记") },
        text = {
            if (bookmarks.isEmpty()) {
                Text("暂无书签。阅读页点击“加书签”可记录当前位置和笔记。")
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(bookmarks, key = { it.id }) { mark ->
                        Card(colors = CardDefaults.cardColors()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(mark.title, fontWeight = FontWeight.Bold, maxLines = 1)
                                if (mark.note.isNotBlank()) Text(mark.note, fontSize = 13.sp)
                                Text(formatter.format(Date(mark.createdAt)), fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { onJump(mark) }) { Text("跳转") }
                                    TextButton(onClick = { onDelete(mark) }) { Text("删除") }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("关闭") } },
    )
}

@Composable
private fun BookmarkEditorDialog(chapter: Chapter, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("添加书签笔记") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(chapter.title) })
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("笔记（可选）") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = { Button(onClick = { onSave(note) }) { Text("保存") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}

@Composable
private fun ReaderSettingsDialog(
    settings: ReaderSettings,
    onDismiss: () -> Unit,
    onSettingsChange: (ReaderSettings) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("阅读设置") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("主题")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReaderTheme.entries.forEach { theme ->
                        FilterChip(
                            selected = settings.theme == theme,
                            onClick = { onSettingsChange(settings.copy(theme = theme)) },
                            label = { Text(theme.label) },
                        )
                    }
                }
                Text("行距 ${"%.1f".format(settings.lineHeight)}")
                Slider(
                    value = settings.lineHeight,
                    onValueChange = { onSettingsChange(settings.copy(lineHeight = it.coerceIn(1.2f, 2.4f))) },
                    valueRange = 1.2f..2.4f,
                )
                Text("分页字符数 ${settings.pageChars}")
                Slider(
                    value = settings.pageChars.toFloat(),
                    onValueChange = { onSettingsChange(settings.copy(pageChars = it.toInt())) },
                    valueRange = 1200f..9000f,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = settings.paragraphIndent,
                        onCheckedChange = { onSettingsChange(settings.copy(paragraphIndent = it)) },
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("段首缩进")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("完成") } },
    )
}

@Composable
private fun EmptyReader(onBack: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("没有选中的书籍")
            Spacer(Modifier.height(12.dp))
            Button(onClick = onBack) { Text("返回书架") }
        }
    }
}

private fun String.indentParagraphs(): String {
    return lines().joinToString("\n") { line ->
        if (line.isBlank() || line.startsWith("　　")) line else "　　$line"
    }
}
