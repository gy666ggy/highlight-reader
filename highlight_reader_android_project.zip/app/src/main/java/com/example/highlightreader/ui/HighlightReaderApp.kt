package com.example.highlightreader.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.highlightreader.data.ReaderStore
import com.example.highlightreader.model.Book
import com.example.highlightreader.model.ReaderTheme
import com.example.highlightreader.model.Screen
import com.example.highlightreader.ui.reader.ReaderScreen
import com.example.highlightreader.ui.rules.RulesScreen
import com.example.highlightreader.ui.shelf.ShelfScreen
import com.example.highlightreader.ui.sources.SourceRulesScreen
import java.util.UUID

@Composable
fun HighlightReaderApp() {
    val context = LocalContext.current
    var books by remember { mutableStateOf(ReaderStore.loadBooks(context)) }
    var rules by remember { mutableStateOf(ReaderStore.loadRules(context)) }
    var settings by remember { mutableStateOf(ReaderStore.loadSettings(context)) }
    var bookmarks by remember { mutableStateOf(ReaderStore.loadBookmarks(context)) }
    var sources by remember { mutableStateOf(ReaderStore.loadSourceRules(context)) }
    var screen by remember { mutableStateOf(Screen.Shelf) }
    var selectedBookId by remember { mutableStateOf(books.firstOrNull()?.id) }

    LaunchedEffect(books) { ReaderStore.saveBooks(context, books) }
    LaunchedEffect(rules) { ReaderStore.saveRules(context, rules) }
    LaunchedEffect(settings) { ReaderStore.saveSettings(context, settings) }
    LaunchedEffect(bookmarks) { ReaderStore.saveBookmarks(context, bookmarks) }
    LaunchedEffect(sources) { ReaderStore.saveSourceRules(context, sources) }

    val currentBook = books.firstOrNull { it.id == selectedBookId }
    val dark = settings.theme == ReaderTheme.Dark

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Surface(modifier = Modifier.fillMaxSize()) {
            when (screen) {
                Screen.Shelf -> ShelfScreen(
                    books = books,
                    rules = rules,
                    bookmarks = bookmarks,
                    sources = sources,
                    onImport = { title, content ->
                        val book = Book(
                            id = UUID.randomUUID().toString(),
                            title = title.ifBlank { "未命名书籍" },
                            content = content,
                        )
                        books = listOf(book) + books
                        selectedBookId = book.id
                        screen = Screen.Reader
                    },
                    onOpen = {
                        selectedBookId = it.id
                        screen = Screen.Reader
                    },
                    onDelete = { target ->
                        books = books.filterNot { it.id == target.id }
                        bookmarks = bookmarks.filterNot { it.bookId == target.id }
                        if (selectedBookId == target.id) selectedBookId = books.firstOrNull()?.id
                    },
                    onRules = { screen = Screen.Rules },
                    onSources = { screen = Screen.Sources },
                )

                Screen.Reader -> ReaderScreen(
                    book = currentBook,
                    rules = rules,
                    settings = settings,
                    bookmarks = bookmarks.filter { it.bookId == currentBook?.id },
                    onBack = { screen = Screen.Shelf },
                    onRules = { screen = Screen.Rules },
                    onSettingsChange = { settings = it },
                    onBookmarksChange = { changed ->
                        val other = bookmarks.filterNot { it.bookId == currentBook?.id }
                        bookmarks = other + changed
                    },
                    onProgressChange = { book, offset ->
                        books = books.map {
                            if (it.id == book.id) it.copy(lastOffset = offset) else it
                        }
                    },
                )

                Screen.Rules -> RulesScreen(
                    rules = rules,
                    onBack = { screen = if (currentBook == null) Screen.Shelf else Screen.Reader },
                    onRulesChange = { rules = it },
                )

                Screen.Sources -> SourceRulesScreen(
                    sources = sources,
                    onBack = { screen = Screen.Shelf },
                    onSourcesChange = { sources = it },
                )
            }
        }
    }
}
