package com.example.highlightreader.domain

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import com.example.highlightreader.model.HighlightRule
import java.util.regex.Pattern
import kotlin.math.max

object HighlightEngine {
    fun render(text: String, rules: List<HighlightRule>, search: String): AnnotatedString {
        val activeRules = rules
            .filter { it.enabled && it.pattern.isNotBlank() }
            .sortedByDescending { it.priority }

        return buildAnnotatedString {
            append(text)
            activeRules.forEach { rule ->
                rule.findRanges(text).forEach { range ->
                    addStyle(
                        style = SpanStyle(background = Color(rule.color)),
                        start = range.first,
                        end = range.last + 1,
                    )
                }
            }
            if (search.isNotBlank()) {
                HighlightRule(
                    id = "search",
                    name = "搜索",
                    pattern = search,
                    color = Color(0xFF80DEEA).toArgb(),
                ).findRanges(text).forEach { range ->
                    addStyle(SpanStyle(background = Color(0xFF80DEEA)), range.first, range.last + 1)
                }
            }
        }
    }

    fun HighlightRule.findRanges(text: String): List<IntRange> {
        return runCatching {
            if (regex) {
                val flags = if (caseSensitive) 0 else Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
                Pattern.compile(pattern, flags).matcher(text).let { matcher ->
                    buildList {
                        while (matcher.find()) {
                            if (matcher.start() < matcher.end()) add(matcher.start() until matcher.end())
                        }
                    }
                }
            } else {
                val source = if (caseSensitive) text else text.lowercase()
                val target = if (caseSensitive) pattern else pattern.lowercase()
                buildList {
                    var index = source.indexOf(target)
                    while (index >= 0) {
                        add(index until index + target.length)
                        index = source.indexOf(target, index + max(1, target.length))
                    }
                }
            }
        }.getOrDefault(emptyList())
    }
}
