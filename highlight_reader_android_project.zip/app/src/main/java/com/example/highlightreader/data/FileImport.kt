package com.example.highlightreader.data

import android.content.Context
import android.net.Uri
import java.nio.charset.Charset

fun Context.readTextFromUri(uri: Uri): String {
    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return ""
    val charsets = listOf(Charsets.UTF_8, Charset.forName("GB18030"), Charsets.UTF_16)
    charsets.forEach { charset ->
        runCatching {
            return bytes.toString(charset)
        }
    }
    return bytes.toString(Charsets.UTF_8)
}

fun Context.writeTextToUri(uri: Uri, text: String) {
    contentResolver.openOutputStream(uri)?.use { stream ->
        stream.write(text.toByteArray(Charsets.UTF_8))
    }
}

fun Context.resolveDisplayName(uri: Uri): String {
    val fallback = uri.lastPathSegment?.substringAfterLast("/") ?: "本地书籍.txt"
    return contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val nameIndex = cursor.getColumnIndex("_display_name")
        if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else fallback
    } ?: fallback
}
