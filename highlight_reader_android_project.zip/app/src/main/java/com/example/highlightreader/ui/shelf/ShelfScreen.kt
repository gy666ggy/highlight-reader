package com.example.highlightreader.ui.shelf

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.highlightreader.data.readTextFromUri
import com.example.highlightreader.data.resolveDisplayName
import com.example.highlightreader.domain.ChapterParser
import com.example.highlightreader.model.Book
import com.example.highlightreader.model.Bookmark
import com.example.highlightreader.model.HighlightRule
import com.example.highlightreader.model.SourceRule

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShelfScreen(
    books: List<Book>,
    rules: List<HighlightRule>,
    bookmarks: List<Bookmark>,
    sources: List<SourceRule>,
    onImport: (String, String) -> Unit,
    onOpen: (Book) -> Unit,
    onDelete: (Book) -> Unit,
    onRules: () -> Unit,
    onSources: () -> Unit,
) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val title = context.resolveDisplayName(uri)
            val content = context.readTextFromUri(uri)
            onImport(title, content)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Highlight Reader") },
                actions = {
                    TextButton(onClick = onSources) { Text("书源") }
                    TextButton(onClick = onRules) { Text("高亮规则") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFFFF8EF)),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFFFF8EF))
                .padding(padding)
                .padding(18.dp),
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("本地阅读器", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "支持 TXT 导入、章节目录、书签笔记、阅读设置、规则高亮导入导出与书源规则骨架。",
                        color = Color(0xFF5F5146),
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "已启用 ${rules.count { it.enabled }} 条高亮规则 · ${bookmarks.size} 条书签笔记 · ${sources.size} 个书源规则模板。",
                        color = Color(0xFF7C6F64),
                        fontSize = 13.sp,
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { launcher.launch(arrayOf("text/plain", "text/*")) }) {
                            Text("导入 TXT")
                        }
                        OutlinedButton(onClick = onRules) { Text("配置高亮") }
                        OutlinedButton(onClick = onSources) { Text("书源规则") }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text("书架", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (books.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("暂无书籍。点击“导入 TXT”开始阅读。", color = Color(0xFF7C6F64))
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(books, key = { it.id }) { book ->
                        BookCard(
                            book = book,
                            bookmarkCount = bookmarks.count { it.bookId == book.id },
                            onOpen = { onOpen(book) },
                            onDelete = { onDelete(book) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BookCard(book: Book, bookmarkCount: Int, onOpen: () -> Unit, onDelete: () -> Unit) {
    val progress = if (book.content.isBlank()) 0 else (book.lastOffset * 100 / book.content.length)
    val chapterCount = ChapterParser.parse(book.content).size
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(book.title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text(
                "阅读进度 $progress% · ${book.content.length} 字 · $chapterCount 章 · $bookmarkCount 条笔记",
                color = Color(0xFF6B7280),
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onOpen) { Text("继续阅读") }
                OutlinedButton(onClick = onDelete) { Text("删除") }
            }
        }
    }
}
