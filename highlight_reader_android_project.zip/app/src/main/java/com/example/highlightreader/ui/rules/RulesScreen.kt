package com.example.highlightreader.ui.rules

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.highlightreader.data.ReaderStore
import com.example.highlightreader.data.readTextFromUri
import com.example.highlightreader.data.writeTextToUri
import com.example.highlightreader.model.HighlightRule
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RulesScreen(
    rules: List<HighlightRule>,
    onBack: () -> Unit,
    onRulesChange: (List<HighlightRule>) -> Unit,
) {
    val context = LocalContext.current
    var editing by remember { mutableStateOf<HighlightRule?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val imported = ReaderStore.decodeRules(context.readTextFromUri(uri))
            if (imported.isNotEmpty()) {
                onRulesChange(imported)
                message = "已导入 ${imported.size} 条高亮规则"
            } else {
                message = "导入失败：未解析到有效规则"
            }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            context.writeTextToUri(uri, ReaderStore.encodeRules(rules))
            message = "已导出 ${rules.size} 条高亮规则"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("高亮规则") },
                navigationIcon = { TextButton(onClick = onBack) { Text("返回") } },
                actions = {
                    TextButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) }) { Text("导入") }
                    TextButton(onClick = { exportLauncher.launch("highlight_rules.json") }) { Text("导出") }
                    TextButton(onClick = {
                        editing = null
                        showEditor = true
                    }) { Text("新增") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFFFF8EF)),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFFFF8EF))
                .padding(padding)
                .padding(18.dp),
        ) {
            Text("规则会在阅读页自动匹配文本，并按优先级、颜色高亮。支持普通关键词、正则、大小写与 JSON 导入导出。", color = Color(0xFF6B5E54))
            if (message != null) {
                Spacer(Modifier.height(8.dp))
                Text(message.orEmpty(), color = Color(0xFF2563EB))
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(rules, key = { it.id }) { rule ->
                    RuleCard(
                        rule = rule,
                        onToggle = {
                            onRulesChange(rules.map { if (it.id == rule.id) it.copy(enabled = !it.enabled) else it })
                        },
                        onEdit = {
                            editing = rule
                            showEditor = true
                        },
                        onDelete = {
                            onRulesChange(rules.filterNot { it.id == rule.id })
                        },
                    )
                }
            }
        }
    }

    if (showEditor) {
        RuleEditorDialog(
            rule = editing,
            onDismiss = { showEditor = false },
            onSave = { saved ->
                onRulesChange(
                    if (editing == null) listOf(saved) + rules else rules.map { if (it.id == saved.id) saved else it },
                )
                showEditor = false
            },
        )
    }
}

@Composable
private fun RuleCard(rule: HighlightRule, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .width(18.dp)
                        .height(18.dp)
                        .background(Color(rule.color), RoundedCornerShape(5.dp)),
                )
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(rule.name, fontWeight = FontWeight.Bold)
                    Text(rule.pattern, color = Color(0xFF6B7280), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Checkbox(checked = rule.enabled, onCheckedChange = { onToggle() })
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(if (rule.regex) "正则" else "关键词") })
                AssistChip(onClick = {}, label = { Text(if (rule.caseSensitive) "区分大小写" else "忽略大小写") })
                AssistChip(onClick = {}, label = { Text("优先级 ${rule.priority}") })
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onEdit) { Text("编辑") }
                OutlinedButton(onClick = onDelete) { Text("删除") }
            }
        }
    }
}

@Composable
private fun RuleEditorDialog(rule: HighlightRule?, onDismiss: () -> Unit, onSave: (HighlightRule) -> Unit) {
    var name by remember(rule) { mutableStateOf(rule?.name ?: "") }
    var pattern by remember(rule) { mutableStateOf(rule?.pattern ?: "") }
    var regex by remember(rule) { mutableStateOf(rule?.regex ?: false) }
    var caseSensitive by remember(rule) { mutableStateOf(rule?.caseSensitive ?: false) }
    var priority by remember(rule) { mutableIntStateOf(rule?.priority ?: 0) }
    var color by remember(rule) { mutableStateOf(rule?.color ?: Color(0xFFFFE082).toArgb()) }
    val palette = listOf(
        Color(0xFFFFF176),
        Color(0xFFFFAB91),
        Color(0xFFA5D6A7),
        Color(0xFF90CAF9),
        Color(0xFFCE93D8),
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (rule == null) "新增高亮规则" else "编辑高亮规则") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("名称") }, singleLine = true)
                OutlinedTextField(value = pattern, onValueChange = { pattern = it }, label = { Text("关键词或正则") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = regex, onCheckedChange = { regex = it })
                    Text("使用正则表达式")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = caseSensitive, onCheckedChange = { caseSensitive = it })
                    Text("区分大小写")
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("优先级 $priority")
                    OutlinedButton(onClick = { priority -= 1 }) { Text("-") }
                    OutlinedButton(onClick = { priority += 1 }) { Text("+") }
                }
                Text("颜色")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    palette.forEach { item ->
                        Box(
                            modifier = Modifier
                                .width(34.dp)
                                .height(34.dp)
                                .background(item, RoundedCornerShape(9.dp))
                                .clickable { color = item.toArgb() },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (color == item.toArgb()) Text("✓", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = pattern.isNotBlank(),
                onClick = {
                    onSave(
                        HighlightRule(
                            id = rule?.id ?: UUID.randomUUID().toString(),
                            name = name.ifBlank { pattern.take(12) },
                            pattern = pattern,
                            color = color,
                            regex = regex,
                            caseSensitive = caseSensitive,
                            enabled = rule?.enabled ?: true,
                            priority = priority,
                        ),
                    )
                },
            ) { Text("保存") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        },
    )
}
