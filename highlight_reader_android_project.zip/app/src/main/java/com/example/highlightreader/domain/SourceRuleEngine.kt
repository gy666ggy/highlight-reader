package com.example.highlightreader.domain

import com.example.highlightreader.model.SourceRule

data class SourceSearchRequest(val keyword: String, val page: Int = 1)

data class SourceFetchPlan(
    val searchUrl: String,
    val bookNameSelector: String,
    val chapterListSelector: String,
    val contentSelector: String,
)

object SourceRuleEngine {
    fun buildSearchPlan(rule: SourceRule, request: SourceSearchRequest): SourceFetchPlan {
        val encodedKeyword = request.keyword.trim().replace(" ", "%20")
        val url = rule.searchUrl
            .replace("{keyword}", encodedKeyword)
            .replace("{page}", request.page.toString())

        return SourceFetchPlan(
            searchUrl = resolveUrl(rule.baseUrl, url),
            bookNameSelector = rule.bookNameSelector,
            chapterListSelector = rule.chapterListSelector,
            contentSelector = rule.contentSelector,
        )
    }

    fun validate(rule: SourceRule): List<String> {
        return buildList {
            if (rule.name.isBlank()) add("书源名称不能为空")
            if (rule.baseUrl.isBlank()) add("baseUrl 不能为空")
            if (!rule.searchUrl.contains("{keyword}")) add("searchUrl 建议包含 {keyword} 占位符")
            if (rule.bookNameSelector.isBlank()) add("bookNameSelector 不能为空")
            if (rule.chapterListSelector.isBlank()) add("chapterListSelector 不能为空")
            if (rule.contentSelector.isBlank()) add("contentSelector 不能为空")
        }
    }

    private fun resolveUrl(baseUrl: String, path: String): String {
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        return baseUrl.trimEnd('/') + "/" + path.trimStart('/')
    }
}
