package com.example.highlightreader.domain

import com.example.highlightreader.model.Chapter

object ChapterParser {
    private val titlePattern = Regex(
        pattern = """(?m)^\s*((第[零〇一二三四五六七八九十百千万两\d]+[章节回卷集部篇].{0,40})|(Chapter\s+\d+.{0,40})|(\d+[.、]\s*.{1,40}))\s*$""",
        options = setOf(RegexOption.IGNORE_CASE),
    )

    fun parse(content: String): List<Chapter> {
        if (content.isBlank()) return listOf(Chapter(0, "正文", 0, 0))

        val matches = titlePattern.findAll(content)
            .filter { it.range.first < content.length }
            .toList()

        if (matches.isEmpty()) {
            return splitBySize(content)
        }

        val chapters = mutableListOf<Chapter>()
        if (matches.first().range.first > 0) {
            chapters += Chapter(
                index = 0,
                title = "序章",
                start = 0,
                end = matches.first().range.first,
            )
        }

        matches.forEachIndexed { index, match ->
            val start = match.range.first
            val end = matches.getOrNull(index + 1)?.range?.first ?: content.length
            chapters += Chapter(
                index = chapters.size,
                title = match.value.trim().ifBlank { "章节 ${chapters.size + 1}" },
                start = start,
                end = end,
            )
        }

        return chapters
    }

    fun findChapter(chapters: List<Chapter>, offset: Int): Chapter {
        return chapters.firstOrNull { offset in it.start until it.end }
            ?: chapters.lastOrNull()
            ?: Chapter(0, "正文", 0, 0)
    }

    private fun splitBySize(content: String, size: Int = 8000): List<Chapter> {
        return content.indices.step(size).mapIndexed { index, start ->
            Chapter(
                index = index,
                title = "正文 ${index + 1}",
                start = start,
                end = (start + size).coerceAtMost(content.length),
            )
        }.ifEmpty {
            listOf(Chapter(0, "正文", 0, content.length))
        }
    }
}
