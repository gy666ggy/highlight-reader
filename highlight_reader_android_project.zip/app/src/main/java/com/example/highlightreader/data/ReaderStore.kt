package com.example.highlightreader.data

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.example.highlightreader.model.Book
import com.example.highlightreader.model.Bookmark
import com.example.highlightreader.model.HighlightRule
import com.example.highlightreader.model.ReaderSettings
import com.example.highlightreader.model.ReaderTheme
import com.example.highlightreader.model.SourceRule
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object ReaderStore {
    private const val PREF_NAME = "highlight_reader_store"
    private const val BOOKS_KEY = "books"
    private const val RULES_KEY = "rules"
    private const val SETTINGS_KEY = "settings"
    private const val BOOKMARKS_KEY = "bookmarks"
    private const val SOURCES_KEY = "source_rules"

    fun loadBooks(context: Context): List<Book> {
        val raw = context.shared().getString(BOOKS_KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                Book(
                    id = item.getString("id"),
                    title = item.getString("title"),
                    content = item.getString("content"),
                    lastOffset = item.optInt("lastOffset", 0),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveBooks(context: Context, books: List<Book>) {
        val array = JSONArray()
        books.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("content", it.content)
                    .put("lastOffset", it.lastOffset),
            )
        }
        context.shared().edit().putString(BOOKS_KEY, array.toString()).apply()
    }

    fun loadBookmarks(context: Context): List<Bookmark> {
        val raw = context.shared().getString(BOOKMARKS_KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                Bookmark(
                    id = item.getString("id"),
                    bookId = item.getString("bookId"),
                    chapterIndex = item.optInt("chapterIndex", 0),
                    offset = item.optInt("offset", 0),
                    title = item.optString("title", "书签"),
                    note = item.optString("note", ""),
                    createdAt = item.optLong("createdAt", System.currentTimeMillis()),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveBookmarks(context: Context, bookmarks: List<Bookmark>) {
        val array = JSONArray()
        bookmarks.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("bookId", it.bookId)
                    .put("chapterIndex", it.chapterIndex)
                    .put("offset", it.offset)
                    .put("title", it.title)
                    .put("note", it.note)
                    .put("createdAt", it.createdAt),
            )
        }
        context.shared().edit().putString(BOOKMARKS_KEY, array.toString()).apply()
    }

    fun loadRules(context: Context): List<HighlightRule> {
        val raw = context.shared().getString(RULES_KEY, null)
        if (raw == null) return defaultRules()
        return decodeRules(raw)
    }

    fun saveRules(context: Context, rules: List<HighlightRule>) {
        context.shared().edit().putString(RULES_KEY, encodeRules(rules)).apply()
    }

    fun encodeRules(rules: List<HighlightRule>): String {
        val array = JSONArray()
        rules.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("pattern", it.pattern)
                    .put("color", it.color)
                    .put("regex", it.regex)
                    .put("caseSensitive", it.caseSensitive)
                    .put("enabled", it.enabled)
                    .put("priority", it.priority),
            )
        }
        return JSONObject()
            .put("version", 1)
            .put("rules", array)
            .toString(2)
    }

    fun decodeRules(raw: String): List<HighlightRule> {
        return runCatching {
            val root = raw.trim()
            val array = if (root.startsWith("[")) JSONArray(root) else JSONObject(root).getJSONArray("rules")
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                HighlightRule(
                    id = item.optString("id", UUID.randomUUID().toString()),
                    name = item.optString("name", "未命名规则"),
                    pattern = item.optString("pattern"),
                    color = item.optInt("color", Color(0xFFFFF176).toArgb()),
                    regex = item.optBoolean("regex", false),
                    caseSensitive = item.optBoolean("caseSensitive", false),
                    enabled = item.optBoolean("enabled", true),
                    priority = item.optInt("priority", 0),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun loadSettings(context: Context): ReaderSettings {
        val raw = context.shared().getString(SETTINGS_KEY, null)
        return runCatching {
            val item = JSONObject(raw ?: "{}")
            ReaderSettings(
                fontSize = item.optDouble("fontSize", 20.0).toFloat(),
                lineHeight = item.optDouble("lineHeight", 1.65).toFloat(),
                theme = ReaderTheme.valueOf(item.optString("theme", ReaderTheme.Sepia.name)),
                pageChars = item.optInt("pageChars", 3600).coerceIn(1200, 9000),
                paragraphIndent = item.optBoolean("paragraphIndent", true),
            )
        }.getOrDefault(ReaderSettings())
    }

    fun saveSettings(context: Context, settings: ReaderSettings) {
        val item = JSONObject()
            .put("fontSize", settings.fontSize)
            .put("lineHeight", settings.lineHeight)
            .put("theme", settings.theme.name)
            .put("pageChars", settings.pageChars)
            .put("paragraphIndent", settings.paragraphIndent)
        context.shared().edit().putString(SETTINGS_KEY, item.toString()).apply()
    }

    fun loadSourceRules(context: Context): List<SourceRule> {
        val raw = context.shared().getString(SOURCES_KEY, null)
        if (raw == null) return defaultSourceRules()
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                SourceRule(
                    id = item.optString("id", UUID.randomUUID().toString()),
                    name = item.optString("name", "未命名书源"),
                    baseUrl = item.optString("baseUrl"),
                    searchUrl = item.optString("searchUrl"),
                    bookNameSelector = item.optString("bookNameSelector"),
                    chapterListSelector = item.optString("chapterListSelector"),
                    contentSelector = item.optString("contentSelector"),
                    enabled = item.optBoolean("enabled", false),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveSourceRules(context: Context, sources: List<SourceRule>) {
        val array = JSONArray()
        sources.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("baseUrl", it.baseUrl)
                    .put("searchUrl", it.searchUrl)
                    .put("bookNameSelector", it.bookNameSelector)
                    .put("chapterListSelector", it.chapterListSelector)
                    .put("contentSelector", it.contentSelector)
                    .put("enabled", it.enabled),
            )
        }
        context.shared().edit().putString(SOURCES_KEY, array.toString()).apply()
    }

    private fun defaultRules() = listOf(
        HighlightRule(UUID.randomUUID().toString(), "人物名示例", "主角|先生|姑娘", Color(0xFFFFF176).toArgb(), regex = true, priority = 10),
        HighlightRule(UUID.randomUUID().toString(), "重点词示例", "重要", Color(0xFFA5D6A7).toArgb(), priority = 5),
    )

    private fun defaultSourceRules() = listOf(
        SourceRule(
            id = UUID.randomUUID().toString(),
            name = "书源规则模板",
            baseUrl = "https://example.com",
            searchUrl = "/search?q={keyword}&page={page}",
            bookNameSelector = ".book-title",
            chapterListSelector = ".chapter-list a",
            contentSelector = ".chapter-content",
            enabled = false,
        ),
    )

    private fun Context.shared() = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
}
