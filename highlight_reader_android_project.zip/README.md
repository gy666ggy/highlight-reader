# Highlight Reader

一个原生 Android 阅读器示例，使用 Kotlin 与 Jetpack Compose 开发。当前版本已从单文件原型扩展为多文件结构，覆盖本地阅读器的核心链路：书架、章节目录、书签笔记、规则高亮、阅读设置与书源规则骨架。

## 已实现

- 本地 TXT 文件导入，支持 UTF-8、GB18030、UTF-16 尝试解码。
- 书架列表、继续阅读、删除书籍。
- 章节解析：识别 `第 x 章/节/回`、`Chapter N`、数字标题；未识别时按固定长度自动分段。
- 阅读页目录弹窗、章节跳转、进度 Slider、上一页/下一页。
- 书签笔记：按书籍记录章节、偏移、备注、创建时间；支持查看、跳转、删除。
- 阅读设置：字号、行距、护眼/明亮/夜间主题、分页字符数、段首缩进。
- 当前页搜索高亮。
- 高亮规则管理：普通关键词、正则表达式、颜色、启用/停用、大小写、优先级。
- 高亮规则 JSON 导入与导出。
- 书源规则骨架：Base URL、搜索 URL、书名/目录/正文选择器、启用状态、基础校验与搜索计划生成。
- 书籍、书签、规则、书源规则、阅读设置本地持久化。

## 项目结构

```text
.
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── app
│   ├── build.gradle.kts
│   └── src/main
│       ├── AndroidManifest.xml
│       ├── java/com/example/highlightreader
│       │   ├── MainActivity.kt
│       │   ├── data
│       │   │   ├── FileImport.kt
│       │   │   └── ReaderStore.kt
│       │   ├── domain
│       │   │   ├── ChapterParser.kt
│       │   │   ├── HighlightEngine.kt
│       │   │   └── SourceRuleEngine.kt
│       │   ├── model
│       │   │   └── Models.kt
│       │   └── ui
│       │       ├── HighlightReaderApp.kt
│       │       ├── reader/ReaderScreen.kt
│       │       ├── rules/RulesScreen.kt
│       │       ├── shelf/ShelfScreen.kt
│       │       └── sources/SourceRulesScreen.kt
│       └── res
│           ├── drawable/ic_launcher.xml
│           └── values
```

## 运行方式

1. 使用 Android Studio 打开当前文件夹。
2. 等待 Gradle Sync 完成。
3. 选择模拟器或真机。
4. 点击 Run。

当前环境没有执行构建；源码按标准 Android Studio 项目组织。

## 发布安装包

项目已加入 Release 签名配置、混淆规则和 GitHub Actions 云端打包流程。没有本地 Android SDK/Gradle 时，推荐上传到 GitHub 后用 Actions 生成 APK/AAB。

详细步骤见 [`RELEASE.md`](RELEASE.md)。

## 阅读功能说明

### 章节与目录

导入 TXT 后会自动调用 `ChapterParser` 解析目录。阅读页点击「目录」可查看章节列表并跳转；如果原文没有明显章节标题，会按固定大小生成「正文 1」「正文 2」等虚拟章节。

### 书签笔记

阅读页点击「加书签」可记录当前位置，可填写备注。点击「笔记」可查看当前书籍的所有书签笔记，并支持跳转或删除。

### 阅读设置

阅读页点击「设置」可调整：

- 主题：护眼、明亮、夜间。
- 行距。
- 分页字符数。
- 段首缩进。

## 高亮规则说明

进入「高亮规则」页面后，可以新增、编辑、删除、启用、停用规则，也可以导入/导出 JSON：

- 名称：规则显示名称。
- 关键词或正则：需要匹配的内容。
- 使用正则表达式：开启后按 Regex 匹配。
- 区分大小写：默认忽略大小写。
- 颜色：阅读页中匹配文本的背景色。
- 优先级：数值越高越先应用。

示例：

- 普通关键词：`重要`
- 多关键词正则：`主角|先生|姑娘`
- 数字正则：`\\d+`

导出 JSON 格式：

```json
{
  "version": 1,
  "rules": [
    {
      "id": "uuid",
      "name": "人物名",
      "pattern": "主角|先生|姑娘",
      "color": -8960,
      "regex": true,
      "caseSensitive": false,
      "enabled": true,
      "priority": 10
    }
  ]
}
```

## 书源规则骨架

「书源」页面用于维护在线书源规则的元数据，目前只做规则结构、校验与搜索计划生成，尚未接入网络请求和 HTML 解析。字段包括：

- `baseUrl`：站点根地址。
- `searchUrl`：搜索路径，支持 `{keyword}` 与 `{page}` 占位符。
- `bookNameSelector`：书名 CSS 选择器。
- `chapterListSelector`：目录 CSS 选择器。
- `contentSelector`：正文 CSS 选择器。

## 后续建议

为了进一步接近成熟开源阅读 App，可继续拆分并补齐：

- 书籍格式：EPUB、MOBI、PDF、HTML。
- 章节能力：章节缓存、目录手动修正、卷/分组目录。
- 书源系统：在线搜索、换源、净化规则、失败重试、缓存。
- 阅读体验：翻页动画、横竖屏、沉浸模式、朗读。
- 标注体系：手动划线、范围选择、摘录导出。
- 同步能力：WebDAV、云备份、多端进度同步。
- 规则能力：按书籍/分类启用规则、冲突处理、规则市场。
- 数据层：Room 数据库替代当前 SharedPreferences，适合大量书籍和高亮数据。

## 技术说明

当前版本保留 Kotlin Compose，不引入额外 UI 框架。主要分层：

- `model`：Book、Chapter、Bookmark、HighlightRule、ReaderSettings、SourceRule。
- `data`：本地 SharedPreferences JSON 存储、文件读写。
- `domain`：章节解析、高亮匹配、书源规则校验与计划生成。
- `ui/shelf`：书架页面。
- `ui/reader`：阅读页、目录、书签笔记、阅读设置。
- `ui/rules`：高亮规则管理与导入导出。
- `ui/sources`：书源规则骨架管理。
